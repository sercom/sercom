#include <stdio.h>

int main()
{
	printf("Hello sercom!\n");
	return 0;
}

